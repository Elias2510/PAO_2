create function round(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN round($1, 0);

comment on function round(numeric) is 'value rounded to ''scale'' of zero';

alter function round(numeric) owner to postgres;

